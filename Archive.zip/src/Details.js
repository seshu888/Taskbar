import React from 'react'
import './details.css'
import {useLocation,useParams,useNavigate} from 'react-router-dom';
const Details=()=>{
   const locate= useLocation()
   const navigate=useNavigate()
    const handleNavigate=()=>{
        navigate('/')
    }
   const item = locate.state
    return(
        <div className="detailsContainer">
            <div className='detailsWrapper'>
                <h1><b>Id</b>: {item.id}</h1>
                <span><b>Working Status</b> : {item.workingStatus}</span>
                <span><b>Description</b>: {item.desc}</span>
                <span><b>Type of Taks</b> : {item.taskStatus}</span>
                <span><b>Date of Completion</b>:{item.date}</span>
            </div>
            <button onClick={handleNavigate}>Back to Home</button>
        </div>
    )
}
export default Details